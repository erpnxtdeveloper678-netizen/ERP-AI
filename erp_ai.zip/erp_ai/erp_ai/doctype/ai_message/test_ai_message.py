# Copyright (c) 2026, Shift and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestAIMessage(FrappeTestCase):
	pass
