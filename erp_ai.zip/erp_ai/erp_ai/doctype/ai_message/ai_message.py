# Copyright (c) 2026, Shift and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class AIMessage(Document):
	pass
