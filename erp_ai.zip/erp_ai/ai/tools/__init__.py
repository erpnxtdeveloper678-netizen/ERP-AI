"""
Importing this package registers every AI tool via the @ai_tool decorator
(see erp_ai.ai.decorators / erp_ai.ai.registry). Add new tool modules here.
"""

from erp_ai.ai.tools import system 
from erp_ai.ai.tools import documents
from erp_ai.ai.tools import analytics
from erp_ai.ai.tools import reports
from erp_ai.ai.tools import workflow
from erp_ai.ai.tools import inventory
from erp_ai.ai.tools import finance
from erp_ai.ai.tools import crm
from erp_ai.ai.tools import hr
from erp_ai.ai.tools import automation
from erp_ai.ai.tools import audit
